##########################
#Execute at your own risk#
##########################
this is an early beta
this tool allows easier instalation of custom Borders 2 your snes mini
this as of 28/12/2017 has only been run by me @DeadiyReddit
after executing you just need to open ftp and put your custom borders in /usr/shared/backgrounds and they wil show up


Hi! this is an early beta of something I've been working on, a plugin for hakchi that make adding custom borders to you snes mini easier, right now it only redirects folders via symbolic link in freebsd, which means after running my code you can just add your custom borders to the /usr/shared/backgrounds and they will show up.

Made by @DeadiyReddit